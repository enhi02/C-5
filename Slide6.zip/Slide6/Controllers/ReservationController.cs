﻿using Microsoft.AspNetCore.Mvc;
using Slide6.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Slide6.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReservationController : ControllerBase
    {
        private IReservation _reservationSvc;
        public ReservationController(IReservation reservationSvc)
        {
            _reservationSvc = reservationSvc;
        }

       
        // GET: api/<ReservationController>
        [HttpGet]
        public IEnumerable<Reservation> Get()
        {
            return _reservationSvc.GetAllReservations();
        }

        // GET api/<ReservationController>/5
        [HttpGet("{id}")]
        public Reservation Get(int id)
        {
            return _reservationSvc.Reservations(id);
        }

        // POST api/<ReservationController>
        [HttpPost]
        public Reservation Post([FromBody] Reservation reservation)
        {
            return _reservationSvc.AddReservation(reservation);
        }

        // PUT api/<ReservationController>/5
        [HttpPut("{id}")]
        public Reservation Put(int id,[FromBody] Reservation reservation)
        {
            return _reservationSvc.UpdateReservation(reservation);
        }

        // DELETE api/<ReservationController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            _reservationSvc.DeleteReservation(id);
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Slide6.Models {

    public class UserSvc : IUser
    {
        //private Dictionary<int, Reservation> items;
        protected DataContext _context;
        public UserSvc(DataContext context)
        {
            _context = context;
        }      

        public Reservation Reservations(int id) 
        {
            Reservation reservation = null;
            reservation = _context.Reservations.Find(id); //cách này chỉ dùng cho Khóa chính
            //product = _context.Products.Where(e=>e.Id==id).FirstOrDefault(); //cách tổng quát
            return reservation;           
        }

        public IEnumerable<Reservation> Reservations()
        { 
          return _context.Reservations.ToList();
        }
        

        public Reservation AddReservation(Reservation reservation)
        {            
            try
            {
                reservation.ReservationId = 0;
                _context.Add(reservation);
                _context.SaveChanges();                
            }
            catch(Exception ex)
            {

            }
            return reservation;
        }

        public void DeleteReservation(int id) 
        {
            Reservation reservation = null;
            reservation = _context.Reservations.Find(id);
            _context.Reservations.Remove(reservation);
            
        }

        public Reservation UpdateReservation(Reservation reservation)
        {
            _context.Update(reservation);
            _context.SaveChanges();
            return reservation;
        }        
    }
}

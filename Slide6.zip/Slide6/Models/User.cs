﻿using System.ComponentModel.DataAnnotations;

namespace Slide6.Models {

    public class User {
        [Key]
        public int UserId { get; set; }
        [StringLength(150)]        
        public string FullName { get; set; }
        [StringLength(150)]
        public string Email { get; set; }
        [StringLength(150)]

        public string Password { get; set; }
        [StringLength(150)]
        public string Location { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace Slide6.Models {

    public class Reservation {
        [Key]
        public int ReservationId { get; set; }
        [StringLength(150)]        
        public string ClientName { get; set; }
        [StringLength(150)]
        public string Location { get; set; }
    }
}

﻿using System.Collections.Generic;

namespace Slide6.Models {

    public interface IReservation
    {
        IEnumerable<Reservation> GetAllReservations();
        //Reservation this[int id] { get; }
        Reservation Reservations(int id);

        Reservation AddReservation(Reservation reservation);
        Reservation UpdateReservation(Reservation reservation);
        void DeleteReservation(int id);
    }
}

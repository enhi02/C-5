﻿using System.Collections.Generic;

namespace Slide6_2.Models {

    public interface IReservation
    {
        IEnumerable<Reservation> Reservations();
        //Reservation this[int id] { get; }
        Reservation Reservations(int id);

        Reservation AddReservation(Reservation reservation);
        Reservation UpdateReservation(Reservation reservation);
        void DeleteReservation(int id);
    }
}

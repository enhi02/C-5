﻿using System.ComponentModel.DataAnnotations;

namespace Slide6_2.Models {

    public class Reservation {
        [Key]
        public int ReservationId { get; set; }
        [StringLength(150)]        
        public string ClientName { get; set; }
        [StringLength(150)]
        public string Location { get; set; }
    }
}
